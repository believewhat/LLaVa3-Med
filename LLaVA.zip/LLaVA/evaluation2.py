import json
import ipdb
import glob
import os
import ipdb
from openai import OpenAI
import os
import json
import csv
import pandas as pd
import argparse
import base64
os.environ["OPENAI_API_KEY"]='sk-fV05kSZMhSGzmSz5B99c534e393c4aB4Ba2a7a0e3820Be3f'

client = OpenAI(
  api_key='sk-fV05kSZMhSGzmSz5B99c534e393c4aB4Ba2a7a0e3820Be3f',
  base_url='https://api.xiaoai.plus/v1'
)


def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")

def read_jsonl(file_path):
    data = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            json_line = json.loads(line.strip())
            if json_line['conversations'][1]["value"] == 'yes' or json_line['conversations'][1]["value"] == 'no':
                json_line['conversations'][0]["value"] = json_line['conversations'][0]["value"].replace('Correct Answer:', 'Only return yes or no. Correct Answer:')
            data.append(json_line)
    return data

data_path = "claude3_results-slake.json"
images_path = "/home/jwang/Project/doctorrobot/Mixtral-Multimodal/data/path-vqa/scripts/data/test"
questions = [json.loads(q) for q in open(os.path.expanduser(data_path), "r")][0]
ipdb.set_trace()
for line in questions:
    if 'gpt4_answer' in line.keys():
        continue
    image_file = line["image"]
    qs = line["conversations"][0]["value"].replace('<image>', '')
    image_path = os.path.join(images_path, line["image"])
    images = [{"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{encode_image(image_path)}"}}]
    for i in range(5):
        try:
            response = client.chat.completions.create(
                model="claude-3-sonnet-20240229",
                messages=[
                    {
                        "role": "user", 
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "data": images,
                                },
                            },
                            {
                                "type": "text",
                                "text": f"{qs}\nProvide a short answer for this question"
                            }
                    ]}
                ],
                max_tokens=100
            )
            break
        except:
            ipdb.set_trace()
    result = response.choices[0].message.content
    line['gpt4_answer'] = result
    with open(f"claude3_results.json", "w") as file:
        json.dump(questions, file)
