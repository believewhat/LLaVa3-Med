import json
import os
import transformers
import numpy as np

try:
    questions = [json.loads(q) for q in open(os.path.expanduser('/home/jwang/Project/doctorrobot/Mixtral-Multimodal/data/amboss_data/amboss_test_data.json'), "r")]
except:
    questions = json.load(open(os.path.expanduser('/home/jwang/Project/doctorrobot/Mixtral-Multimodal/data/amboss_data/amboss_test_data.json'), "r"))
answers = [json.loads(q) for q in open(os.path.expanduser('result.jsonl'), "r")]

acc = 0
num = 1

results = []
references = []
for i in range(len(questions)):
    references.append(questions[i]['conversations'][1]["value"])
    results.append(answers[i]['text'])
    num += 1
    
    if questions[i]['conversations'][1]["value"] == answers[i]['text']:
        acc += 1
    else:
        print(questions[i]['conversations'][1]["value"], answers[i]['text'])
print(acc / num)


from nltk.translate.bleu_score import sentence_bleu
from nltk.tokenize import word_tokenize
from sklearn.metrics import precision_recall_fscore_support
def calculate_bleu(reference_texts, candidate_text):
    # Tokenize the sentences
    # 将字符串列表转换为标记序列
    reference_tokens = [word_tokenize(reference_texts.lower())]
    candidate_tokens = word_tokenize(candidate_text.lower())

    score = sentence_bleu(reference_tokens, candidate_tokens, weights=(1, 0, 0, 0))
    return score

def calculate_f1(reference_texts, candidate_texts):
    # 将句子标记化
    reference_tokens = word_tokenize(reference_texts.lower())
    candidate_tokens = word_tokenize(candidate_texts.lower())
    
    # 创建标记匹配的计数
    tp = len(set(reference_tokens) & set(candidate_tokens))
    fp = len(set(candidate_tokens) - set(reference_tokens))
    fn = len(set(reference_tokens) - set(candidate_tokens))
    
    # 计算precision, recall和F1得分
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    return f1


references_en = []
results_en = []
def is_english(s):
    return all(ord(c) < 128 for c in s)
for i in range(len(references)):
    if is_english(references[i]) and is_english(results[i]):
        references_en.append(references[i])
        results_en.append(results[i])
bleu_scores = []
f1_scores = []
for i in range(len(references_en)):
    bleu_score = calculate_bleu(references_en[i], results_en[i])
    bleu_scores.append(bleu_score)
    f1_score = calculate_f1(references_en[i], results_en[i])
    f1_scores.append(f1_score)
print(np.mean(bleu_scores))
print(np.mean(f1_scores))
import ipdb
ipdb.set_trace()

import nltk
from nltk.metrics import f_measure, precision, recall
def compute_f1_score(list1, list2):
    # 将字符串列表转换为标记序列
    token_list1 = [
        tokenizer(
            text,
            return_tensors="pt",
            padding="longest",
            max_length=2024,
            truncation=True,
        ) for text in list1
    ]
    token_list2 = [
        tokenizer(
            text,
            return_tensors="pt",
            padding="longest",
            max_length=2024,
            truncation=True,
        ) for text in list2
    ]

    score = sentence_bleu(reference_tokens, candidate_tokens, weights=(1, 0, 0, 0))
    return score


f1_score = compute_f1_score(references, results)
print("Token F1 score:", f1_score)
import ipdb
ipdb.set_trace()