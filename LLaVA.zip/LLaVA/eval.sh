


export CUDA_DEVICE_ORDER="PCI_BUS_ID" 

CUDA_VISIBLE_DEVICES=0 python -m evaluation \
        --model-path /data/experiment_data/junda/chatdoctor/med-Llava3-amboss \
        --question-file /home/jwang/Project/doctorrobot/Mixtral-Multimodal/data/amboss_data/amboss_test_data.json \
        --image-folder /home/jwang/Project/uptodata/amboss/images \
        --answers-file result.jsonl \
        --temperature 0.7 \
        --conv-mode llama3