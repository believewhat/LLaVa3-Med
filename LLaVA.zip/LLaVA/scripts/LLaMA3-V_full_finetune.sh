#!/bin/bash
#/home/jwang/Project/doctorrobot/Mixtral-Multimodal/data/pmc-vqa/train_2_instruct.json
#/home/jwang/Project/doctorrobot/Mixtral-Multimodal/data/pmc-vqa/figures 

export CUDA_DEVICE_ORDER="PCI_BUS_ID" 
CUDA_VISIBLE_DEVICES=0,2,3 NCCL_P2P_DISABLE=1 torchrun --nproc_per_node=3 llava/train/train_mem.py \
    --deepspeed ./scripts/zero3.json \
    --model_name_or_path /data/experiment_data/junda/chatdoctor/med-Llava3-instruct-2 \
    --version llama3 \
    --data_path /home/jwang/Project/doctorrobot/Mixtral-Multimodal/data/amboss_data/amboss_train_data.json \
    --image_folder /home/jwang/Project/uptodata/amboss/images \
    --vision_tower /data/experiment_data/junda/chatdoctor/clip-vit-large-patch14-336 \
    --mm_projector_type mlp2x_gelu \
    --mm_vision_select_layer -2 \
    --mm_use_im_start_end False \
    --mm_use_im_patch_token False \
    --image_aspect_ratio pad \
    --group_by_modality_length True \
    --bf16 True \
    --output_dir /data/experiment_data/junda/chatdoctor/med-Llava3-amboss\
    --num_train_epochs 13 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 4 \
    --gradient_accumulation_steps 1 \
    --evaluation_strategy "no" \
    --save_strategy "epoch" \
    --save_total_limit 5 \
    --learning_rate 2e-5 \
    --weight_decay 0. \
    --warmup_ratio 0.03 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --tf32 True \
    --model_max_length 4096 \
    --gradient_checkpointing True \
    --dataloader_num_workers 3 \
    --lazy_preprocess True \
    --report_to none
